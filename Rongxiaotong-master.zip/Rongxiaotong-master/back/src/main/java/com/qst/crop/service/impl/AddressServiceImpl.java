package com.qst.crop.service.impl;

import com.qst.crop.dao.AddressDao;
import com.qst.crop.entity.Address;
import com.qst.crop.service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 马骏
 * @Description 地址类服务层的实现类
 * @Date 2025-01-08
 */

@Service
public class AddressServiceImpl implements AddressService {
    @Autowired
    private AddressDao addressDao;

//    获取当前登录的用户名并绑定到地址对象中。
//    如果新增的地址设置为默认地址，调用 setZero() 清除其他地址的默认状态。
//    调用 DAO 层的 insertSelective 方法，将地址信息插入数据库。
    @Override
    public void add(Address address) {//新增地址
        //获取登陆的用户名
        UserDetails principal = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String name = principal.getUsername();
        address.setOwnName(name);
        if (address.getIsDefault()) {
            // 将别的默认路径清除
            setZero();
        }
        addressDao.insertSelective(address);
    }

//    获取当前登录用户的用户名。
//    调用 DAO 层的 selectByExample 方法，根据用户名查询该用户的所有地址
    @Override
    public List<Address> selectByOwnName() {// 查询所有地址
        //获取登陆的用户名
        UserDetails principal = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String ownName = principal.getUsername();
        List<Address> addresses = addressDao.selectByExample(ownName);
        return addresses;
    }

//    获取当前登录用户的用户名。
//    调用 DAO 层的 selectOneByExample 方法，根据用户名和默认标识查询该用户的默认地址。
    @Override
    public Address selectDefaultByOwnName() {// 查询默认地址
        //获取登陆的用户名
        UserDetails principal = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String name = principal.getUsername();
        String isDef = "1";
        Address address = addressDao.selectOneByExample(name,isDef);

        return address;
    }

//    设置更新的地址为当前用户的地址。
//    如果该地址被设置为默认地址，清除其他地址的默认状态。
//    调用 update 方法更新地址信息。
    @Override
    public void defaultAddressInfoUpdate(Address address) {//更新默认地址
        //获取登陆的用户名
        UserDetails principal = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String name = principal.getUsername();

        address.setOwnName(name);
        if (address.getIsDefault()) {
            // 将别的默认路径清除
            setZero();
        }
        update(address);
    }

//    调用 DAO 层的 updateByPrimaryKey 方法，更新地址信息。
    @Override
    public void update(Address address) {// 更新地址信息
        addressDao.updateByPrimaryKey(address);
    }

//    检查目标地址是否为默认地址，若是则禁止删除。
//    否则调用 DAO 层的 deleteByPrimaryKey 方法删除地址。
    @Override
    public boolean delete(Integer id) {//删除地址
        Address address = addressDao.selectByPrimaryKey(id);
        if (address.getIsDefault()){
            return false;
        }else {
            addressDao.deleteByPrimaryKey(id);
            return true;
        }
    }

    /**
     * 让所有的地址默认值设为0
     */
//    查询当前用户的默认地址。
//    如果存在默认地址，将其默认状态清除并更新
    public void setZero() {// 清除其他默认地址
        Address address = selectDefaultByOwnName();
        if (null != address)
        {
            address.setIsDefault(false);
            update(address);
        }
    }

}
