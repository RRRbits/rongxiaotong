package com.qst.crop.service;

import com.qst.crop.entity.Address;

import java.util.List;

/**
 * @author 马骏
 * @Description  地址类服务层
 * @Date  2025-01-08
 */

public interface AddressService {
    void add(Address address);//添加地址

    List<Address> selectByOwnName();//查询当前用户所有地址

    Address selectDefaultByOwnName();// 查询当前用户的默认地址


    void defaultAddressInfoUpdate(Address address);//更新默认地址信息

    void update(Address address);//根据 ID 更新地址

    boolean delete(Integer id);//删除地址
}
